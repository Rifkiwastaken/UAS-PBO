package Database;

//interface
public interface Pemesanan {
    public void noPemesanan();
    public void namaCustomer();
    public void jenisps();
    public void hargasewa();
    public void lamapenyewaan();
    public void totalHarga();

}
